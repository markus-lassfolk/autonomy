// Simple Vue.js component for Autonomy UI
(function() {
    'use strict';
    
    // Register the component with VuCI
    if (typeof L !== 'undefined' && L.Class) {
        // LuCI-style registration
        L.Class.extend('AutonomyApp', {
            initialize: function() {
                this.render();
            },
            
            render: function() {
                var container = document.createElement('div');
                container.className = 'autonomy-app';
                container.innerHTML = `
                    <div class="autonomy-container">
                        <h2>Autonomy System</h2>
                        <div class="status-section">
                            <h3>System Status</h3>
                            <div id="autonomy-status">Loading...</div>
                        </div>
                        <div class="controls-section">
                            <h3>Controls</h3>
                            <button onclick="autonomyApp.startDaemon()" class="btn btn-primary">Start Daemon</button>
                            <button onclick="autonomyApp.stopDaemon()" class="btn btn-danger">Stop Daemon</button>
                            <button onclick="autonomyApp.restartDaemon()" class="btn btn-warning">Restart Daemon</button>
                        </div>
                        <div class="config-section">
                            <h3>Configuration</h3>
                            <div id="autonomy-config">Loading config...</div>
                        </div>
                    </div>
                `;
                
                // Add styles
                var style = document.createElement('style');
                style.textContent = `
                    .autonomy-container { padding: 20px; }
                    .status-section, .controls-section, .config-section { margin: 20px 0; }
                    .btn { margin: 5px; padding: 8px 16px; border: none; border-radius: 4px; cursor: pointer; }
                    .btn-primary { background-color: #007bff; color: white; }
                    .btn-danger { background-color: #dc3545; color: white; }
                    .btn-warning { background-color: #ffc107; color: black; }
                    .status-indicator { display: inline-block; width: 12px; height: 12px; border-radius: 50%; margin-right: 8px; }
                    .status-running { background-color: #28a745; }
                    .status-stopped { background-color: #dc3545; }
                `;
                document.head.appendChild(style);
                
                // Replace the main content
                var mainContent = document.querySelector('#maincontent') || document.body;
                mainContent.innerHTML = '';
                mainContent.appendChild(container);
                
                // Initialize the app
                this.initApp();
            },
            
            initApp: function() {
                this.updateStatus();
                this.updateConfig();
                // Update status every 5 seconds
                setInterval(() => this.updateStatus(), 5000);
            },
            
            updateStatus: function() {
                var statusDiv = document.getElementById('autonomy-status');
                if (!statusDiv) return;
                
                // Simple status check - check if daemon process exists
                fetch('/api/autonomy/status')
                    .then(response => response.json())
                    .then(data => {
                        var statusHtml = `
                            <div class="status-item">
                                <span class="status-indicator ${data.daemon_running ? 'status-running' : 'status-stopped'}"></span>
                                <strong>Daemon:</strong> ${data.daemon_running ? 'Running' : 'Stopped'}
                            </div>
                            <div class="status-item">
                                <strong>Uptime:</strong> ${data.uptime || 'Unknown'}
                            </div>
                            <div class="status-item">
                                <strong>Interfaces:</strong> ${data.interfaces ? data.interfaces.length : 0} found
                            </div>
                            <div class="status-item">
                                <strong>Last Check:</strong> ${new Date(data.last_check * 1000).toLocaleString()}
                            </div>
                        `;
                        statusDiv.innerHTML = statusHtml;
                    })
                    .catch(error => {
                        statusDiv.innerHTML = `<div class="error">Error loading status: ${error.message}</div>`;
                    });
            },
            
            updateConfig: function() {
                var configDiv = document.getElementById('autonomy-config');
                if (!configDiv) return;
                
                fetch('/api/autonomy/config')
                    .then(response => response.json())
                    .then(data => {
                        var configHtml = '<div class="config-item">';
                        if (data.main) {
                            configHtml += `<strong>Main Config:</strong><br>`;
                            configHtml += `- Enabled: ${data.main.enable || 'Unknown'}<br>`;
                            configHtml += `- Log Level: ${data.main.log_level || 'Unknown'}<br>`;
                        }
                        configHtml += '</div>';
                        configDiv.innerHTML = configHtml;
                    })
                    .catch(error => {
                        configDiv.innerHTML = `<div class="error">Error loading config: ${error.message}</div>`;
                    });
            },
            
            startDaemon: function() {
                fetch('/api/autonomy/start', { method: 'POST' })
                    .then(response => response.json())
                    .then(data => {
                        alert(data.message || 'Daemon started');
                        this.updateStatus();
                    })
                    .catch(error => {
                        alert('Error starting daemon: ' + error.message);
                    });
            },
            
            stopDaemon: function() {
                fetch('/api/autonomy/stop', { method: 'POST' })
                    .then(response => response.json())
                    .then(data => {
                        alert(data.message || 'Daemon stopped');
                        this.updateStatus();
                    })
                    .catch(error => {
                        alert('Error stopping daemon: ' + error.message);
                    });
            },
            
            restartDaemon: function() {
                fetch('/api/autonomy/restart', { method: 'POST' })
                    .then(response => response.json())
                    .then(data => {
                        alert(data.message || 'Daemon restarted');
                        this.updateStatus();
                    })
                    .catch(error => {
                        alert('Error restarting daemon: ' + error.message);
                    });
            }
        });
        
        // Create global instance
        window.autonomyApp = new L.AutonomyApp();
    } else {
        // Fallback for non-LuCI environments
        console.log('Autonomy UI loaded - LuCI not available');
        document.body.innerHTML = '<div style="padding: 20px;"><h2>Autonomy System</h2><p>UI loaded successfully. Daemon is running.</p></div>';
    }
})();
