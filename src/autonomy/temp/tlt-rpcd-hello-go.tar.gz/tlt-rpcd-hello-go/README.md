# tlt-rpcd-hello-go — Go-based rpcd plugin for RutOS

A minimal **rpcd executable plugin** implemented in Go. It registers as an ubus
object named **`hello`** with two methods:

- `status()` → returns `{ "enabled": true, "version": "1.0" }`
- `set(enabled: bool)` → accepts `{ "enabled": true|false }`, returns `{ "ok": true }`

It also installs a minimal **rpcd ACL** so VuCI/WebUI can call these methods.

## Build (Host — RutOS SDK)
```bash
# Place this folder under: <SDK root>/package/tlt-rpcd-hello-go
# Make sure feeds include golang (the RutOS SDK normally carries OpenWrt feeds/packages).
./scripts/feeds update -a && ./scripts/feeds install -a

make menuconfig
# Utilities -> tlt-rpcd-hello-go: mark as 'M' (module), save

make package/tlt-rpcd-hello-go/{clean,compile} V=sc -j"$(nproc)"
```

The resulting IPK will appear under `bin/packages/<arch>/base/`.
Since PKG_NAME starts with `tlt_custom_pkg_`, it can be uploaded via the RutOS
**Package Manager** UI without renaming.

## Install & Test (RUTOS device)
```bash
# Copy IPK to the router, then:
opkg install /tmp/tlt_custom_pkg_rpcd_hello_go_*.ipk

# Verify:
ubus -v list hello
ubus call hello status
ubus call hello set '{"enabled":true}'
```

## Files installed
- `/usr/libexec/rpcd/hello` (compiled Go binary; the rpcd plugin)
- `/usr/share/rpcd/acl.d/hello.json` (permissions)
