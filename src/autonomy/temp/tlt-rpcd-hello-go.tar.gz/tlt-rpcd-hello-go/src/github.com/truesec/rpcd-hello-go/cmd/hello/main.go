package main

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
	"strings"
	"time"
)

// CallInput is a permissive input map for method arguments.
type CallInput map[string]any

func list() {
	// Advertise methods and argument schema for rpcd to register on ubus.
	// The schema is a JSON object of method -> argSpec.
	fmt.Print(`{"status":{},"set":{"enabled":true}}`)
}

func call(method string, r io.Reader) error {
	switch method {
	case "status":
		out := map[string]any{
			"enabled": true,
			"version": "1.0",
			"ts":      time.Now().Unix(),
		}
		enc := json.NewEncoder(os.Stdout)
		return enc.Encode(out)

	case "set":
		var in CallInput
		dec := json.NewDecoder(r)
		_ = dec.Decode(&in) // permissive; ignore errors for minimal demo
		// TODO: persist 'enabled' with UCI or act on it
		fmt.Print(`{"ok":true}`)
		return nil

	default:
		fmt.Print(`{"error":"unknown method"}`)
		return nil
	}
}

func usage() {
	fmt.Fprintln(os.Stderr, "Usage: hello list | call <method>")
}

func main() {
	if len(os.Args) < 2 {
		usage()
		os.Exit(2)
	}
	switch strings.ToLower(os.Args[1]) {
	case "list":
		list()
	case "call":
		if len(os.Args) < 3 {
			usage()
			os.Exit(2)
		}
		_ = call(os.Args[2], os.Stdin)
	default:
		usage()
		os.Exit(2)
	}
}
