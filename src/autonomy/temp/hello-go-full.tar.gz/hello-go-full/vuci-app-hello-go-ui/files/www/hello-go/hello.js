(function(){
  function readCookie(name){
    const m = document.cookie.match(new RegExp('(^| )'+name+'=([^;]+)')); return m?decodeURIComponent(m[2]):null;
  }
  async function ubusCall(obj, method, params){
    // Try to reuse LuCI/VuCI session token from cookie 'sysauth'
    const sid = readCookie('sysauth') || readCookie('ubus_sessionid') || null;
    const payload = {
      jsonrpc: "2.0",
      id: 1,
      method: "call",
      params: [ sid, obj, method, params || {} ]
    };
    const res = await fetch("/ubus", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      credentials: "same-origin"
    });
    const data = await res.json();
    if(data.error) throw data.error;
    return data.result && data.result[1] ? data.result[1] : data;
  }
  async function main(){
    const root = document.getElementById('hello-go') || document.body;
    const pre = document.createElement('pre');
    pre.textContent = "Calling ubus hello.status ...";
    root.appendChild(pre);
    try{
      const s = await ubusCall("hello","status",{});
      pre.textContent = "hello.status → "+JSON.stringify(s,null,2);
      const btn = document.createElement('button');
      btn.textContent = "Call hello.set {enabled:true}";
      btn.onclick = async ()=>{
        const r = await ubusCall("hello","set",{enabled:true});
        alert("hello.set result: "+JSON.stringify(r));
      };
      root.appendChild(btn);
    }catch(e){
      pre.textContent = "Error calling ubus: "+JSON.stringify(e);
    }
  }
  document.addEventListener('DOMContentLoaded', main);
})();