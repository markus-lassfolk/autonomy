# tlt-rpcd-hello-go — Go-based rpcd plugin for RutOS

Installs an ubus object **`hello`** via rpcd executable plugin with methods:
  - `status()` → `{"enabled":true,"version":"1.0","ts":<unix>}`
  - `set(enabled: bool)` → accepts JSON; returns `{"ok":true}`

## Build (RutOS SDK)
```bash
# <SDK root>/package/tlt-rpcd-hello-go
./scripts/feeds update -a && ./scripts/feeds install -a
make menuconfig   # Utilities -> tlt-rpcd-hello-go: 'M'
make package/tlt-rpcd-hello-go/{clean,compile} V=sc -j"$(nproc)"
```

## Install & test (router)
```bash
opkg install /tmp/tlt_custom_pkg_rpcd_hello_go_*.ipk
ubus -v list hello
ubus call hello status
ubus call hello set '{"enabled":true}'
```
