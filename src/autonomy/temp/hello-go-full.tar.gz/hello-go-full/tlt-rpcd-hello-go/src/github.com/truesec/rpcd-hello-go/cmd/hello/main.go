package main

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
	"strings"
	"time"
)

type CallInput map[string]any

func list() {
	fmt.Print(`{"status":{},"set":{"enabled":true}}`)
}

func call(method string, r io.Reader) error {
	switch method {
	case "status":
		out := map[string]any{
			"enabled": true,
			"version": "1.0",
			"ts":      time.Now().Unix(),
		}
		return json.NewEncoder(os.Stdout).Encode(out)
	case "set":
		var in CallInput
		_ = json.NewDecoder(r).Decode(&in)
		fmt.Print(`{"ok":true}`)
		return nil
	default:
		fmt.Print(`{"error":"unknown method"}`)
		return nil
	}
}

func usage() {
	fmt.Fprintln(os.Stderr, "Usage: hello list | call <method>")
}

func main() {
	if len(os.Args) < 2 {
		usage()
		os.Exit(2)
	}
	switch strings.ToLower(os.Args[1]) {
	case "list":
		list()
	case "call":
		if len(os.Args) < 3 {
			usage()
			os.Exit(2)
		}
		_ = call(os.Args[2], os.Stdin)
	default:
		usage()
		os.Exit(2)
	}
}
