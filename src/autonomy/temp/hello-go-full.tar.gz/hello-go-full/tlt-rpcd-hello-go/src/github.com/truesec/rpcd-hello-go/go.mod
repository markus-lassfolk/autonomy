module github.com/truesec/rpcd-hello-go

go 1.22.0
