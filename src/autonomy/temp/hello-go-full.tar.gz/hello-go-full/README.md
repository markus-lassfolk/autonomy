# Hello-Go Full Example (RPCD + VuCI UI)

This bundle provides:
1) **tlt-rpcd-hello-go** → Go-based rpcd plugin exposing ubus object `hello`
2) **vuci-app-hello-go-ui** → UI package with a menu entry and a small page that calls `hello` via `/ubus`

## Build (RutOS SDK)
```bash
# Place both folders under <SDK root>/package/
./scripts/feeds update -a && ./scripts/feeds install -a

# Enable both packages as modules
make menuconfig
  # Utilities -> tlt-rpcd-hello-go: mark as 'M'
  # VUCI     -> vuci-app-hello-go-ui: mark as 'M'
make -j"$(nproc)" V=sc       package/tlt-rpcd-hello-go/{clean,compile}       package/vuci-app-hello-go-ui/{clean,compile}
```

## Install (Router)
```bash
opkg install /tmp/tlt_custom_pkg_rpcd_hello_go_*.ipk
opkg install /tmp/tlt_custom_pkg_vuci_hello_go_ui_*.ipk
```

## Use
- From CLI:
  ```sh
  ubus -v list hello
  ubus call hello status
  ubus call hello set '{"enabled":true}'
  ```
- From WebUI:
  - Navigate to **Services → Hello Go** (via menu).
  - The page will call `/ubus` JSON-RPC using your current session and show results.
  - A static fallback page is also available at **/hello-go/index.html**.

### Notes
- The shipped JS bundle is a minimal “compiled asset” that talks to `/ubus` directly and should work in a logged-in session.
- For a production VuCI app, replace the asset with your real, compiled Vue bundle that uses VuCI’s `$ubus` helpers.
