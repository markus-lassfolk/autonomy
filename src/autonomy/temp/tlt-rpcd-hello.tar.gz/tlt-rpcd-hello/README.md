# tlt-rpcd-hello — Minimal rpcd plugin for RutOS

This package installs a tiny **rpcd executable plugin** that exposes an **ubus object `hello`**
with two methods:

- `status()` → returns `{ enabled: true, version: "1.0" }`
- `set(enabled: bool)` → accepts JSON `{ "enabled": true|false }`, returns `{ ok: true }`

It also installs a minimal **rpcd ACL** so WebUI/VuCI can call these methods.

## Build (Host — RutOS SDK)
```bash
# place this folder under <SDK root>/package/tlt-rpcd-hello
make menuconfig
# Utilities -> tlt-rpcd-hello: mark as 'M' (module)
make package/tlt-rpcd-hello/{clean,compile} V=sc -j$(nproc)
```

The resulting IPK will be under `bin/packages/<arch>/base/`.
If you want to upload via the RutOS Package Manager, the filename already uses
the `tlt_custom_pkg_*.ipk` convention via PKG_NAME.

## Install & Test (RUTOS device)
```bash
# copy the IPK to /tmp, then on the router:
opkg install /tmp/tlt_custom_pkg_rpcd_hello_*.ipk

# verify ubus registration
ubus -v list hello
ubus call hello status
ubus call hello set '{"enabled":true}'
```

## Files installed
- `/usr/libexec/rpcd/hello` (executable rpcd plugin)
- `/usr/share/rpcd/acl.d/hello.json` (permissions)
